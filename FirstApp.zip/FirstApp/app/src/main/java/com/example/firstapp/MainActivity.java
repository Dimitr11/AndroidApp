package com.example.firstapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {
    Button button;
    LinearLayout linearLayout;
    EditText editText;
    EditText editTextColorName;
    String editTextValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.button);
        editText = findViewById(R.id.colorChange);
        linearLayout = findViewById(R.id.linearLayout);
        editTextColorName = findViewById(R.id.colorValue);


        editTextValue = editText.getText().toString();

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(editTextValue.equals("purple_200"))
                    linearLayout.getResources().getColor(R.color.purple_200);
                else if(editTextValue.equals("purple_500"))
                    linearLayout.getResources().getColor(R.color.purple_500);
                else if(editTextValue.equals("black")) {
                    linearLayout.getResources().getColor(R.color.black);
                    editTextColorName.getResources().getColor(R.color.white);
                }
                else
                    editTextColorName.setText("Entrer une couleur valide");
            }
        });

    }
}